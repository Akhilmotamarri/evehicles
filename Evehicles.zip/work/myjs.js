function open(){
    document.querySelector('.bg-modal').style.display = 'flex';
}

setTimeout(open, 3000);
document.querySelector('.close').addEventListener('click', function close(){
    document.querySelector('.bg-modal').style.display = 'none',pointer='cursor';
});